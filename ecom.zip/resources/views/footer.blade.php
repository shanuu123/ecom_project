
<div  style="clear:both" class="panel panel-defoult ">
    <div class="panel-body trending-name">
        panel content
    </div>
    <div class="panel-footer trending-panel">panel footer</div>
</div>