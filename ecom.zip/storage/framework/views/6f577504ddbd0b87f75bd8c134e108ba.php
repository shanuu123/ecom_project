
<?php $__env->startSection("content"); ?>

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

<div class="" >
    <div class="row ">
        <div class="col-sm-6">
            
            <img class="detail-image" src="<?php echo e($product['gallery']); ?>">
        </div>
        <div class="col-sm-6">
           <h2 >
             <div   id="success_message"   style="background-color: lightsalmon"></div></h2>
            
            <h4>name :<?php echo e($product['name']); ?></h4>
            <h4>price :<?php echo e($product['price']); ?></h4>
            <h4>category :<?php echo e($product['category']); ?></h4>
            <h4>discription :<?php echo e($product['discription']); ?></h4>
            <br><br>
            
                <?php echo csrf_field(); ?>
                <input type="hidden" id="value_of_cart_id" name="product_id" value=<?php echo e($product['id']); ?>>
                <button class="btn btn-primary add_to_cart"   style="background-color: lightsalmon">Ad To Cart</button>
            
            <br><br>
            <a href="/">Go back</a>
            
            <br><br>
        </div>
    </div>


    <div class="modal fade" id="addcartmodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" >
          <div class="modal-content">
            <div class="modal-header" style="background-color: lightsalmon">
              <h3 class="modal-title" id="exampleModalLabel">add cart verification</h3>
              <button type="button" class="btn-close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
      
                             
                         <input type="hidden" id="add_item_id" >
                         <h4>are you sure you want to add thi sitem into your cart items?if you want then confirm it</h4>
                
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
              <button type="button" class="btn btn-primary addthecart" >confirm</button>
            </div>
          </div>
        </div>
      </div>






      <script>

       


       
        $(document).ready(function()
        {
          
            
        
            $('body').on('click','.add_to_cart',function(e)
            {
              
                e.preventDefault();
                var cart_id = $('#value_of_cart_id').val();
              
            $('#add_item_id').val(cart_id);
            $('#addcartmodal').modal('show');
        
  
         
            });
            
          
            
            $(document).on('click','.addthecart',function(e){
            e.preventDefault();
            var cart_id = $('#value_of_cart_id').val();
       
          $.ajaxSetup({
                    headers: {
                             'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                             }
                            });
    
        $.ajax({
            type:"POST",
            url:"/add-cart/"+cart_id,
            datatype:"json",
            success:function(response){
               $('#addcartmodal').modal('hide');
               $('#success_message').text(response.message)
               var existing_qty = $('#cart_qty').text();
               var new_qty = parseInt(existing_qty) + 1;
                $('#cart_qty').text(new_qty);
         
            }
        }); 
     
     });

   

   


    });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecom\resources\views/detail.blade.php ENDPATH**/ ?>