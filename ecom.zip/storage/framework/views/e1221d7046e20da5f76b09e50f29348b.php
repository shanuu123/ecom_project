
<?php $__env->startSection("content"); ?>



<div class="container admin-l">
<div class="split left">
  <div class="centered">
    <img src="https://m.media-amazon.com/images/I/51u8M3VsOGL._AC_SX679_.jpg" alt="Avatar woman">
    <h2>Jane Flex</h2>
    <p>Some text.</p>
  </div>
</div>

<div class="splitt right">
  <div class="centered">
    <img src="https://m.media-amazon.com/images/I/51u8M3VsOGL._AC_SX679_.jpg" alt="Avatar man">
    <h2>John Doe</h2>
    <p>Some text here too.</p>
  </div>
</div>
</div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecom\resources\views/productdetail.blade.php ENDPATH**/ ?>