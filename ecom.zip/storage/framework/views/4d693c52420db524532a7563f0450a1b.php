
<div id="products">


    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-md-4" >
     <div class="card" style="margin: 2%">
       <a href="/detail/<?php echo e($items['id']); ?>">
       <img class="card-img-top"  style="height: 250px ; object-fit:contain" src=<?php echo e($items['gallery']); ?> alt="watches">
       <div class="card-body" style="color:black ; height:120px" >
         <h5 class="card-title " style="font-size: 200%"><?php echo e($items['name']); ?></h5>
         <p class="card-text"><?php echo e($items['discription']); ?></p>
         
       </div></a>
     </div>
 
   </div>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div><?php /**PATH C:\xampp\htdocs\ecom\resources\views/products.blade.php ENDPATH**/ ?>